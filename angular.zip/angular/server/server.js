var express = require('express');
var app = express();
var request = require('request');
var bodyParser = require('body-parser');
//静态资源管理
app.use(express.static('public'))
// 创建 application/json 解析 
var jsonParser = bodyParser.json() 
// 创建 application/x-www-form-urlencoded 解析 
var urlencodedParser = bodyParser.urlencoded({ extended: false })

app.all('*', function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Content-Type,Content-Length, Authorization, Accept,X-Requested-With");
    res.header("Access-Control-Allow-Methods","PUT,POST,GET,DELETE,OPTIONS");
    res.header("X-Powered-By",' 3.2.1')
    if(req.method=="OPTIONS") res.send(200);/*让options请求快速返回*/
    else  next();
});
//基础的api路径 baseURL
var baseURL = "https://mrobot.pconline.com.cn/s-300/best/cms/listHomepagev2.xsp?"
//get :请求内容放在请求链接内
//post:放到一个对象里
//http://localhost:3000/api/jingxuan?
//req: 存储了请求信息,请求的内容会放置到req的query属性Hong Kong
//sectionID: 99 精选  0: 优惠 1: 海淘 2 发现 34: 原创
//
app.get('/api/home',function(req,res){
    var sectionId = req.query.sectionId;
    var pageNo = req.query.pageNo;
    var pageSize = req.query.pageSize;
    var url = `${baseURL}sectionId=${sectionId}&pageNo=${pageNo}&pageSize=${pageSize}`
    // 在node服务器中向其他的服务器发起请求
    // console.log(url);
    request(url, function (error, response, body) {
        res.send(body);
    });
})

app.listen(3000,function(req,res){
    console.log("在浏览器中输入 http://localhost:3000");
})