import { Component, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {HttpClient,HttpHeaders} from '@angular/common/http'
import {Location} from '@angular/common'
import { Router } from '@angular/router';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
@Injectable()
export class AppComponent {
  constructor(
    private http: HttpClient,
    private location: Location,
    public _router: Router
    ){}
  count=0;
  tabs= [
    {title: '首页',path:'/home'},
    {title: '分类',path:'/category'},
    {title: '我的',path:'/profile'}
  ];
  
  /**
   * 
   * @param path 跳转的路由
   * 通过router的navigateByUrl通过URL进行跳转
   */
  pushView(mypath:string){
    this._router.navigateByUrl(mypath);
  }
  getGoods(){
    this.http.get("http://localhost:3000/api/home").subscribe((resp)=>{
      
    })
  }
  title = 'angularDemo';
}
