import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import {Router} from '@angular/router'

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
   private registForm: FormGroup;
 
  mobileValidator(control: FormControl): any{
 
  	const mobileReg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1}))+\d{8})$/;
  	const result = mobileReg.test(control.value);
  	return result ? null : { mobile: { info: '请输入正确的手机号' } };
  }
  equalValidator(group: FormGroup): any {
   
    const password = group.get('password') as FormControl;
    const pconfirm = group.get('pconfirm') as FormControl;
    const isEqule: boolean = ( password.value === pconfirm.value);
    return isEqule ? null : { equal: { info: '两次密码不一致' } };
}
   constructor(private fb: FormBuilder,private _router:Router) {
        this.registForm = this.fb.group({
            username: ['', [Validators.required, Validators.minLength(6)]],
            mobile: ['',this.mobileValidator],
            passwordGroup: this.fb.group({
                password: ['',Validators.minLength(6)],
                pconfirm: ['']
            },{validator: this.equalValidator})
        });
    }
 
 
    onSubmit(){
      // 将注册信息放到本地,这里没有做新增.每次注册之后都会把上一次的信息清空,重新写入
       localStorage.setItem('userInfo',
       JSON.stringify({
         username:this.registForm.get('username').value,
         mobile: this.registForm.get('mobile').value,
         password: this.registForm.get('passwordGroup').value.password
        }))
       localStorage.setItem("loggedIn",'1');
      if(this.registForm.valid){
        alert("恭喜你,注册成功!")
        this._router.navigate(['/profile']);
      }
    }
  // heroForm: FormGroup;
  ngOnInit():void {
   
  }
  
}
