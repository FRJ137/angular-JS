import { Component, OnInit,Injectable } from '@angular/core';
import {Router} from '@angular/router'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(
    public _router: Router
  ) {}
  username = '';
  password="";
  ngOnInit() {
  }
  login(){
    var user = JSON.parse(localStorage.getItem("userInfo"));
    if(this.username==user.username&&this.password==user.password){
       localStorage.setItem("loggedIn",'1');
       this._router.navigate(['/profile'])
    }else{
      window.alert("用户名和密码输入有误,请重新输入")
    }
  }
  pushToRegister(){
    this._router.navigate(['/register'])
  }
}
