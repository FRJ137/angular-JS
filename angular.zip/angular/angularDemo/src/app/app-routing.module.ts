import { NgModule } from '@angular/core';
import  {RouterModule, Routes} from '@angular/router';
import {HomeComponent} from './home/home.component';
import {CategoryComponent} from './category/category.component'
import {ProfileComponent} from './profile/profile.component'
import {LoginComponent} from  './login/login.component'
import {RegisterComponent} from './register/register.component'
import {LoginGuard} from "./routeGuard/login.guard";
const routes:Routes = [
    {path: 'home',component: HomeComponent},
    {path: 'category',component: CategoryComponent},
    {
      path: 'profile',
      component: ProfileComponent,
      canActivate:[LoginGuard]
    },
    {path: 'login',component:LoginComponent},
    {path: 'register',component:RegisterComponent}
]
@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule],
    providers:[LoginGuard]
})
// const routes:Routes = [
//   {path: '/home',component: HomeComponent}
// ]
export class AppRoutingModule { }
