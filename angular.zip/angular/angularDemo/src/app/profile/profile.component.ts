import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router'
@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  constructor(private _route:Router) { }
  ngOnInit() {
    console.log("个人中心初始化");
  }
  logout(){
    localStorage.setItem("loggedIn","0");
    this._route.navigate(['/login'])
  }
}
