import { Component, Injectable } from '@angular/core';
import {CanActivate} from "@angular/router";
import { Router } from '@angular/router';
/**
 * 使用路由守卫来验证登录,
 */
@Injectable()
export class LoginGuard implements CanActivate {
    constructor(
        private _router: Router
    ){}
    canActivate() {
        let loggedIn = Boolean(parseInt(localStorage.getItem("loggedIn")));
        console.log(loggedIn);
        if (!loggedIn) {
            // 跳转到login页面,带上要原来要访问的页面的地址,在登录完成之后,根据参数跳转回原来的路径
            this._router.navigate(['/login'], { queryParams: {'redirectTo':'/profile' } });
        }
        return loggedIn;
    }
}
