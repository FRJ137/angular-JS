import {Pipe,PipeTransform} from '@angular/core';
import { createOfflineCompileUrlResolver } from '@angular/compiler';
@Pipe({name: 'filterDate'})
export class FilterDatePipe implements PipeTransform {
    transform(value: string): string {
        // 过滤时间
        /**
         * 如果时间小于1一天大于1小时,按小时来显示
         * 24*60*60*1000
         * 如果小于1小时,按分钟来显示
         * 
         */
        var oneDay = 24*60*60*1000; //一天所经历的毫秒数
        var oneHour = 60*60*1000;//一小时所经历的毫秒数
        var currentDate = new Date();
        var date = new Date(value);
        var mine = currentDate.getTime()-parseFloat(value);
        var hour = date.getHours();
        var min = date.getMinutes();
        var month = date.getMonth()+1;
        var day = date.getDate();
        if(mine<oneDay){
            if(mine>oneHour){
                return hour+":"+min
            }else{
                /**
                 * 如果当前时间减去上传时间大于0,表示当前时间和上传时间在同一个小时内
                 * 如果小于0,表示当前之间已经进入下一个小时,
                 */
                    return Math.abs(currentDate.getMinutes()-date.getMinutes())+"分钟前"
            }
            
        }
      
        return month+"-"+day;
    }
}
